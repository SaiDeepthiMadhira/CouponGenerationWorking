
function validateCouponForm(){
	var id=couponsform.id.value;
	var couponcode=couponsform.couponcode.value;
	var description=couponsform.description.value;
	var amount=couponsform.amount.value;
	var issuedate=couponsform.issuedate.value;
	var expirydate=couponsform.expirydate.value;
	//var validname=/^[A-Z][a-zA-Z]{2,}$/;
	//var dateformat = /^(0?[1-9]|1[012])[\/]\d{2}$/;
	var dateformat = /^\d{4}-\d{2}-\d{2}$/
	//var validmobileNo=/^\d{10}$/;
	var flag=false;
	if(id==""||id==null){
		alert("Please enter id");
	}
	/*else if(validname.test(firstname) == false)
	{
alert("Please enter a vaild id");
	}*/
	else if(couponcode=="" || couponcode==null)
		{
		alert("Please enter couponcode");
		}
	
	else if(description=="" || description==null)
	{
	alert("Please enter description");
	}
	else if(amount=="" || amount==null)
	{
	alert("Please enter amount");
	}
	else if(issuedate=="" || issuedate==null)
	{
	alert("Please enter expiry date");
	}
	else if(dateformat.test(issuedate) == false)
	{
alert("Please enter a vaild date mm/dd/yyyy");
	}
	
	
	else if(expirydate=="" || expirydate==null)
	{
	alert("Please enter expiry date");
	}
	else if(dateformat.test(expirydate) == false)
	{
alert("Please enter a vaild date mm/dd/yyyy");
	}
	
	else{
		flag=true;
		alert("Coupon Created successfully");
	}
		return flag;
}
