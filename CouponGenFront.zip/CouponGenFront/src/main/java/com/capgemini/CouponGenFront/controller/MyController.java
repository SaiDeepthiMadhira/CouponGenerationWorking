package com.capgemini.CouponGenFront.controller;


import javax.validation.Valid;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.capgemini.CouponGenFront.model.Coupons;

@Controller
public class MyController {
	@RequestMapping("/")
	public String deepthi() {
		//System.out.println("hello");
		return "GenerateCoupon";
	}
	
	@RequestMapping("/GenerateCoupon")
	public String getPilotForm(ModelMap map) {
		//List<Pilot> pilots= pilotService.getAll();
		
		final String uri="http://localhost:8088/CouponGenBack/api/v1/coupons";
		RestTemplate restTemplate=new RestTemplate();
		
		Coupons[] coupons= restTemplate.getForObject(uri, Coupons[].class);
		
		
		map.put("coupons",coupons);
		map.put("coupons", new Coupons());
		
		return "GenerateCoupon";
	}
	
	@PostMapping("/savecoupon")
	public String showCouponDetails(
			@Valid @ModelAttribute("coupons") Coupons coupons,
			BindingResult result) {
		if(!result.hasErrors()) {
			
			final String uri="http://localhost:8088/CouponGenBack/api/v1/coupons";
			RestTemplate restTemplate=new RestTemplate();
			
		
			restTemplate.postForEntity(uri,coupons,Coupons.class);
		
		
		}
		//map.put("coupons",coupons);

		return "GenerateCoupon";
	}
	
}
