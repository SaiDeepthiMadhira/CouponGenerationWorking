package com.capgemini.CouponGenBack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CouponGenBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(CouponGenBackApplication.class, args);
	}
}
