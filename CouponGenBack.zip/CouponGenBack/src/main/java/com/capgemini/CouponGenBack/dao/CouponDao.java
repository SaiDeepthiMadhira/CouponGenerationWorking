package com.capgemini.CouponGenBack.dao;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.CouponGenBack.model.Coupons;
@Repository("coupondao")
public interface CouponDao extends JpaRepository<Coupons,Integer> {

}
